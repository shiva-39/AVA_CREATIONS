const exp = require('express');
const bcryptjs = require('bcryptjs');
const jwt = require('jsonwebtoken');
const expressAsyncHandler = require('express-async-handler');
require('dotenv').config();

const router = exp.Router();

let userObj, adminObj;
router.use((req, res, next) => {
  userObj = req.app.get("users");
  adminObj = req.app.get("admins");
  next();
});

router.post("/register", expressAsyncHandler(async (req, res) => {
  let body = req.body;
  const dbUser = await userObj.findOne({ username: body.username });
  if (dbUser !== null)
    res.send({ message: "User already exists" });
  else {
    const hash = await bcryptjs.hash(body.password, 7);
    body.password = hash;
    console.log(body)
    await userObj.insertOne(body);
    res.send({ message: "User registered" });
  }
}));

router.post("/login", expressAsyncHandler(async (req, res) => {
  const user = req.body;
  const dbUser = await userObj.findOne({ username: user.username });
  if (dbUser === null)
    res.send({ message: "Invalid username" });
  else {
    const status = await bcryptjs.compare(user.password, dbUser.password);
    if (status === false)
      res.send({ message: "Invalid password" });
    else {
      const signedToken = jwt.sign({ username: dbUser.username }, process.env.SECRET_KEY, { expiresIn: "1d" });
      res.send({ message: "Login successful", token: signedToken, user: dbUser });
    }
  }
}));

router.post('/adminlogin', expressAsyncHandler(async (req, res) => {
  const admin = req.body
  const dbadmin = await adminObj.findOne({ username: admin.username })
  if (dbadmin === null)
    res.send({ message: "Invalid username" })
  else {
    const status = (admin.password === dbadmin.password)
    if (status === false)
      res.send({ message: "Invalid password" })
    else {
      const signedToken = jwt.sign({ username: dbadmin.username }, process.env.SECRET_KEY, { expiresIn: '1d' })
      res.send({ message: "Login successful", token: signedToken, admin: dbadmin })
    }
  }
}))

module.exports = router;
