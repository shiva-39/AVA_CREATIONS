const exp = require('express');
const bcryptjs = require('bcryptjs');
const jwt = require('jsonwebtoken');
const expressAsyncHandler = require('express-async-handler');
const verifyToken = require('../middleware/verifyToken');
require('dotenv').config();

const schemeRouter = exp.Router();

let schemeObj;
schemeRouter.use((req, res, next) => {
  schemeObj = req.app.get("schemes");
  next();
});

schemeRouter.post("/add-scheme", verifyToken, expressAsyncHandler(async (req, res) => {
  let body = req.body;
  const dbscheme = await schemeObj.findOne({ schemeName: body.schemeName });
  if (dbscheme !== null)
    res.send({ message: "Scheme already exists" });
  else {
    console.log(body)
    await schemeObj.insertOne(body);
    res.send({ message: "scheme registered" });
  }
}));

// Get schemes by occupation (public access)
schemeRouter.get("/get-schemes/:occupation", expressAsyncHandler(async (req, res) => {
  try {
    const occupation = req.params.occupation;
    console.log("Fetching schemes for occupation:", occupation);

    // Find schemes that match the occupation
    const schemes = await schemeObj.find({
      occupation: { $regex: occupation, $options: 'i' }
    }).toArray();

    console.log("Found schemes:", schemes);
    res.json(schemes);
  } catch (error) {
    console.error("Error fetching schemes:", error);
    res.status(500).json({ message: "Error fetching schemes", error: error.message });
  }
}));

// Get all schemes (public access)
schemeRouter.get("/get-all-schemes", expressAsyncHandler(async (req, res) => {
  try {
    const schemes = await schemeObj.find({}).toArray();
    res.json(schemes);
  } catch (error) {
    console.error("Error fetching all schemes:", error);
    res.status(500).json({ message: "Error fetching schemes", error: error.message });
  }
}));

schemeRouter.post("/add-scheme", expressAsyncHandler(async (req, res) => {
  let body = req.body;
  const dbscheme = await schemeObj.findOne({ schemeName: body.schemeName });
  if (dbscheme !== null)
    res.send({ message: "Scheme already exists" });
  else {
    console.log(body)
    await schemeObj.insertOne(body);
    res.send({ message: "scheme registered" });
  }
}));
module.exports = schemeRouter;