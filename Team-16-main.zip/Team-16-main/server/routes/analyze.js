require("dotenv").config();
const express = require("express");
const { GoogleGenerativeAI } = require("@google/generative-ai");

const router = express.Router();

router.use(express.json({ limit: "10mb" })); // To handle base64 image size

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const PROMPT = `
Analyze the crop in the provided image and identify if it shows signs of any disease, pest attack, deficiency, or other visible damage.
If damage or defect is found, provide exactly 4 practical and immediate remedies or preventive actions that a farmer or person can take on the spot to reduce the damage or prevent its spread.

The result must be in this strict JSON format only:
{
  "defect_detected": true,
  "defect_type": "Short description of issue",
  "remedies": [
    "First actionable step",
    "Second actionable step",
    "Third actionable step",
    "Fourth actionable step"
  ]
}

If no defect is detected, respond as:
{
  "defect_detected": false,
  "defect_type": "None",
  "remedies": []
}
`;

router.post("/", async (req, res) => {
  try {
    const { base64Image, mimeType } = req.body;

    if (!base64Image || !mimeType) {
      return res.status(400).json({ error: "Missing image or MIME type" });
    }

    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    const result = await model.generateContent([
      {
        inlineData: {
          mimeType,
          data: base64Image,
        },
      },
      PROMPT,
    ]);

    const text = await result.response.text();

    const jsonStart = text.indexOf("{");
    const jsonEnd = text.lastIndexOf("}");
    const jsonString = text.slice(jsonStart, jsonEnd + 1);

    return res.json(JSON.parse(jsonString));
  } catch (err) {
    console.error("Gemini error:", err);
    res.status(500).json({ error: "Gemini analysis failed" });
  }
});

module.exports = router;