import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

function UserLogin() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const [errMsg, setErr] = useState("");
  const navigate = useNavigate();

  async function handleFormSubmit(loginObj) {
    console.log(loginObj);
    const res = await axios.post("http://localhost:4000/auth/login", loginObj);
    if (res.data.message === "Login successful") {
      localStorage.setItem("token", res.data.token);
      navigate(`../dashboard`, { state: res.data.user });
    } else {
      setErr(res.data.message);
    }
  }

  return (
    <div className="flex flex-col md:flex-row mx-auto bg-white rounded shadow-lg p-8 mt-10 max-w-3xl">
      {/* Form Section */}
      <div className="md:w-1/2 w-full p-4">
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
          <p className="text-red-500 text-center text-lg">{errMsg}</p>
          <h1 className="text-center text-2xl font-semibold">Login</h1>

          <div>
            <label className="block text-sm font-medium">Username</label>
            <Input
              type="text"
              {...register("username", { required: true })}
              className="mt-1"
            />
            {errors.password && (
              <p className="text-red-500 text-sm">* Required</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium">Password</label>
            <Input
              type="password"
              {...register("password", { required: true })}
              className="mt-1"
            />
            {errors.password && (
              <p className="text-red-500 text-sm">* Required</p>
            )}
          </div>

          <Button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
          >
            Submit
          </Button>
        </form>
      </div>

      {/* Info Section */}
      <div className="md:w-1/2 w-full bg-emerald-100 rounded-md flex flex-col justify-center items-center p-6">
        <h1 className="text-xl font-semibold text-emerald-800 mb-4">
          Not yet Registered?
        </h1>
        <Link to="/signup" className="text-emerald-600 hover:underline text-lg">
          Register
        </Link>
      </div>
    </div>
  );
}

export default UserLogin;
