import React from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { UserPlus, LogIn, ShieldCheck } from "lucide-react";

export default function HomePage() {
  const navigate = useNavigate();
  return (
    <section className="container mx-auto flex flex-col items-center px-4 py-24 text-center">
      <h2 className="mb-4 text-4xl font-bold text-gray-800 md:text-5xl">
        Manage & scale your craft
      </h2>
      <p className="mx-auto mb-10 max-w-2xl text-lg text-gray-600">
        Access schemes, track inventory, and streamline finances — all in one place.
      </p>

      <div className="flex flex-wrap justify-center gap-6">
        {[
          {
            icon: UserPlus,
            title: "Get Started",
            desc: "Create an account",
            route: "/auth",
          },
          {
            icon: LogIn,
            title: "Sign In",
            desc: "Access your space",
            route: "/login",
          },
          {
            icon: ShieldCheck,
            title: "Admin",
            desc: "Admin console",
            route: "/admin",
          },
        ].map(({ icon: Icon, title, desc, route }) => (
          <Card
            key={title}
            onClick={() => navigate(route)}
            className="w-48 cursor-pointer border-0 bg-white/80 backdrop-blur transition hover:shadow-lg"
          >
            <CardHeader className="items-center gap-2 pb-4 text-center">
              <Icon className="h-10 w-10 text-teal-600" />
              <CardTitle>{title}</CardTitle>
              <CardDescription>{desc}</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </div>
    </section>
  );
}
