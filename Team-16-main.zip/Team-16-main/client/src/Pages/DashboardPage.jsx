import React, { useEffect, useState, useMemo } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { FileText, Building, Boxes } from "lucide-react";
import axios from "axios";

export default function DashboardPage() {
  const { state } = useLocation();
  const occupation = useMemo(
    () => state?.occupation || [],
    [state?.occupation]
  );

  const navigate = useNavigate();

  const [schemes, setSchemes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchSchemes() {
      try {
        // Handle occupation as an array - get the first one for the API call
        const occupationType = Array.isArray(occupation)
          ? occupation[0]
          : occupation;

        if (!occupationType) {
          console.log("No occupation specified, loading default schemes");
          // If no occupation, fetch all schemes
          const res = await axios.get(
            `http://localhost:4000/scheme/get-all-schemes`
          );
          setSchemes(res.data);
        } else {
          console.log("Fetching schemes for:", occupationType);
          const res = await axios.get(
            `http://localhost:4000/scheme/get-schemes/${occupationType}`
          );
          setSchemes(res.data);
        }
      } catch (error) {
        console.error("Error fetching schemes:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchSchemes();
  }, [occupation]);

  const inventory = [
    { name: "Raw Silk", qty: 45, unit: "kg", status: "In Stock" },
    { name: "Mulberry Leaves", qty: 120, unit: "kg", status: "Low Stock" },
    { name: "Cocoons", qty: 200, unit: "pcs", status: "In Stock" },
    { name: "Dyes", qty: 8, unit: "bottles", status: "Critical" },
  ];
  async function fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result.split(",")[1]);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
  async function handleIssue() {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";

    input.onchange = async (event) => {
      const file = event.target.files[0];
      if (!file) return;

      const base64Image = await fileToBase64(file);
      const ext = file.name.split(".").pop().toLowerCase();
      const mimeMap = {
        jpg: "image/jpeg",
        jpeg: "image/jpeg",
        png: "image/png",
      };
      const mimeType = mimeMap[ext];

      const res = await fetch("http://localhost:4000/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ base64Image, mimeType }),
      });

      const data = await res.json();
      console.log("Gemini Analysis:", data);
      navigate("/analyze", { state: { analysis: data } });
    };

    input.click();
  }

  return (
    <section className="container mx-auto px-4 py-12 space-y-8">
      <Tabs defaultValue="schemes" className="w-full space-y-6">
        <TabsList className="grid w-full grid-cols-3 bg-white shadow rounded-lg overflow-hidden">
          <TabsTrigger
            value="schemes"
            className="flex items-center justify-center gap-2 py-3"
          >
            <FileText className="h-5 w-5" />
            <span className="text-sm font-medium">Schemes</span>
          </TabsTrigger>
          <TabsTrigger
            value="bank"
            className="flex items-center justify-center gap-2 py-3"
          >
            <Building className="h-5 w-5" />
            <span className="text-sm font-medium">Bank</span>
          </TabsTrigger>
          <TabsTrigger
            value="inventory"
            className="flex items-center justify-center gap-2 py-3"
          >
            <Boxes className="h-5 w-5" />
            <span className="text-sm font-medium">Inventory</span>
          </TabsTrigger>
        </TabsList>

        {/* ─────────── Schemes Tab */}
        <TabsContent value="schemes" className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-800">
              Available Schemes
            </h2>
            <Badge className="text-sm px-3 py-1">{occupation}</Badge>
          </div>

          {loading ? (
            <p className="text-center text-gray-500">Loading schemes...</p>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {schemes.map((s) => (
                <Card
                  key={s.schemeName}
                  className="transition-shadow hover:shadow-md bg-white"
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-base font-semibold text-gray-800">
                        {s.schemeName}
                      </CardTitle>
                      <Badge variant="default">Active</Badge>
                    </div>
                    <CardDescription className="text-sm text-gray-500">
                      {s.description || ""}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <p className="text-sm">
                      <strong>Required Documents:</strong>{" "}
                      {s.documents.join(", ")}
                    </p>
                    <p className="text-sm">
                      <strong>Benefits:</strong> {s.benefits}
                    </p>
                    <Button
                      size="sm"
                      className="mt-2"
                      onClick={() => window.open(s.link, "_blank")}
                    >
                      Apply
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ─────────── Bank Tab */}
        <TabsContent value="bank" className="space-y-6">
          <h2 className="text-xl font-semibold text-gray-800">Bank Details</h2>
          <Card className="mx-auto max-w-2xl bg-white">
            <CardHeader>
              <CardTitle className="text-base font-medium text-gray-700">
                Primary Account
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                {["Bank Name", "Account Number", "IFSC", "Account Holder"].map(
                  (field) => (
                    <div key={field}>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        {field}
                      </label>
                      <Input placeholder={field} />
                    </div>
                  )
                )}
              </div>
              <Button className="w-full">Save</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─────────── Inventory Tab */}
        <TabsContent value="inventory" className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-800">Inventory</h2>
            <Button>Add Item</Button>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {inventory.map((item) => (
              <Card key={item.name} className="border-l-4">
                <CardContent className="flex items-center justify-between p-4">
                  <div>
                    <h4 className="font-semibold text-gray-800">{item.name}</h4>
                    <p className="text-sm text-gray-600">
                      {item.qty} {item.unit}
                    </p>
                  </div>
                  <Badge
                    variant={
                      item.status === "Critical"
                        ? "destructive"
                        : item.status === "Low Stock"
                        ? "secondary"
                        : "default"
                    }
                  >
                    {item.status}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* ─────────── Report Button */}
      <div className="text-center pt-4">
        <Button
          onClick={handleIssue}
          className="bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-6 rounded-2xl text-lg"
        >
          Report an Issue
        </Button>
      </div>
    </section>
  );
}
