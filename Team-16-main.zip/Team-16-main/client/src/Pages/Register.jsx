import React, { useState, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";

export default function Register() {
  const {
    register,
    handleSubmit,
    setValue,
    control,
    formState: { errors },
  } = useForm({
    defaultValues: {
      gender: "",
      occupation: "",
    },
  });
  const [err, setErr] = useState("");
  const navigate = useNavigate();
  const [selectedIDs, setSelectedIDs] = useState([]);

  useEffect(() => {
    setValue("IDs", selectedIDs);
  }, [selectedIDs, setValue]);

  const toggleID = (id) => {
    setSelectedIDs((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  async function handleFormSubmit(Obj) {
    console.log(Obj);
    const res = await axios.post("http://localhost:4000/auth/register", Obj);
    if (res.status === 201) navigate("/login");
    else setErr(res.data.message);
  }

  return (
    <div className="flex flex-col md:flex-row mx-auto bg-white rounded shadow-lg p-8 mt-10 max-w-4xl">
      {/* Info Section */}
      <div className="md:w-1/2 w-full bg-emerald-100 rounded-md flex flex-col justify-center items-center p-6">
        <h1 className="text-xl font-semibold text-emerald-800 mb-4">
          Already Registered?
        </h1>
        <Link to="/" className="text-emerald-600 hover:underline text-lg">
          Login
        </Link>
      </div>

      {/* Form Section */}
      <div className="md:w-1/2 w-full p-4">
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
          <h1 className="text-center text-2xl font-semibold">
            Create your account
          </h1>

          {err.length !== 0 && (
            <p className="text-green-600 text-center">{err}</p>
          )}

          {/* Full Name and Age */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium">Full Name</label>
              <Input {...register("name", { required: true })} />
            </div>
            <div>
              <label className="block text-sm font-medium">Age</label>
              <Input type="number" {...register("age", { required: true })} />
            </div>
          </div>

          {/* Username and Phone number */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium">Username</label>
              <Input {...register("username", { required: true })} />
            </div>
            <div>
              <label className="block text-sm font-medium">Phone Number</label>
              <Input type="number" {...register("phone", { required: true })} />
            </div>
          </div>

          {/* Gender and Location */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium">Gender</label>
              <Controller
                name="gender"
                control={control}
                rules={{ required: true }}
                render={({ field }) => (
                  <Select
                    onValueChange={field.onChange}
                    value={field.value || ""}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
            </div>
            <div>
              <label className="block text-sm font-medium">Location</label>
              <Input {...register("location", { required: true })} />
            </div>
          </div>

          {/* Government IDs */}
          <div>
            <label className="block text-sm font-medium mb-1">
              Government IDs
            </label>
            <div className="grid grid-cols-2 gap-3">
              {["Aadhar Card", "PAN", "Voter ID", "Ration Card"].map((id) => (
                <label
                  key={id}
                  className="flex items-center gap-2 p-2 border rounded cursor-pointer"
                >
                  <Checkbox
                    checked={selectedIDs.includes(id)}
                    onCheckedChange={() => toggleID(id)}
                    id={id}
                  />
                  <span className="text-sm">{id}</span>
                </label>
              ))}
            </div>
            {errors.IDs && <p className="text-red-500 text-sm">* Required</p>}
          </div>

          {/* Occupation as Radio Group */}
          <div>
            <label className="block text-sm font-medium mb-1">
              Primary Occupation
            </label>
            <div className="flex gap-6">
              {["Weaver", "Rearer"].map((job) => (
                <label
                  key={job}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  <input
                    type="radio"
                    value={job}
                    {...register("occupation", { required: true })}
                    className="h-4 w-4 text-blue-600"
                  />
                  <span className="text-sm">{job}</span>
                </label>
              ))}
            </div>
            {errors.occupation && (
              <p className="text-red-500 text-sm">* Required</p>
            )}
          </div>

          {/* Password */}
          <div>
            <label className="block text-sm font-medium">Password</label>
            <Input
              type="password"
              {...register("password", { required: true })}
              className="mt-1"
            />
            {errors.password && (
              <p className="text-red-500 text-sm">* Required</p>
            )}
          </div>

          <Button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
          >
            Create Account
          </Button>
        </form>
      </div>
    </div>
  );
}
