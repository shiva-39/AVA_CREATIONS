import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Package, ArrowLeft } from "lucide-react";

export default function Header() {
  const { pathname } = useLocation();
  const navigate   = useNavigate();
  const showBack   = pathname !== "/";

  return (
    <header className="sticky top-0 z-20 bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow">
      <div className="container mx-auto flex items-center justify-between px-4 py-3">
        {/* ── CLICKABLE LOGO ────────────────────────────── */}
        <div
          className="flex items-center gap-3 cursor-pointer select-none"
          onClick={() => navigate("/")}
        >
          <span className="rounded-lg bg-white/20 p-2">
            <Package className="h-6 w-6" />
          </span>
          <div>
            <h1 className="text-lg font-bold leading-tight">
              AVACreations
            </h1>
            <p className="text-xs text-emerald-100">Empowering artisans</p>
          </div>
        </div>

        {showBack && (
          <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
            <ArrowLeft className="mr-1 h-4 w-4" />
            Back
          </Button>
        )}
      </div>
    </header>
  );
}
