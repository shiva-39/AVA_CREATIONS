import axios from "axios";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ShieldCheck } from "lucide-react";

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const [errMsg, setErr] = useState("");

  async function handleFormSubmit(loginObj) {
    // console.log(loginObj);
    const res = await axios.post(
      "http://localhost:4000/auth/adminlogin",
      loginObj
    );
    if (res.data.message === "Login successful") {
      localStorage.setItem("token", res.data.token);
      navigate("../scheme-form");
    } else {
      setErr(res.data.message);
    }
  }

  return (
    <div className="flex flex-col md:flex-row mx-auto bg-white rounded shadow-lg p-8 mt-10 max-w-3xl">
      {/* Info Section */}
      <div className="md:w-1/2 w-full bg-emerald-100 rounded-md flex flex-col justify-center items-center p-6">
        <h1 className="text-xl font-semibold text-emerald-800 mb-4">
          Admin Access Only
        </h1>
        <p className="text-emerald-700 text-sm text-center">
          Use authorized credentials to proceed to scheme management.
        </p>
      </div>

      {/* Form Section */}
      <div className="md:w-1/2 w-full p-4">
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-5">
          <p className="text-red-500 text-center text-lg">{errMsg}</p>
          <div className="flex items-center justify-center gap-2 text-emerald-700">
            <ShieldCheck className="h-6 w-6" />
            <h2 className="text-2xl font-semibold">Admin Login</h2>
          </div>

          <div>
            <label className="block text-sm font-medium">Username</label>
            <Input
              placeholder="Admin username"
              {...register("username", { required: true })}
              className="mt-1"
            />
            {errors.username && (
              <p className="text-red-500 text-sm">* Required</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium">Password</label>
            <Input
              type="password"
              {...register("password", { required: true })}
              className="mt-1"
            />
            {errors.password && (
              <p className="text-red-500 text-sm">* Required</p>
            )}
          </div>

          <Button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
          >
            Login
          </Button>
        </form>
      </div>
    </div>
  );
}
