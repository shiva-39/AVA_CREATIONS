import React from "react";
import { useForm, Controller } from "react-hook-form";
// import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function GovernmentSchemeForm() {
  // const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    watch,
    control,
    setValue,
    formState: { errors },
  } = useForm({
    defaultValues: {
      schemeName: "",
      startDate: "",
      endDate: "",
      occupation: "",
      documents: [],
      benefits: "",
    },
  });

  const formData = watch();

  const toggleDoc = (doc) => {
    const docs = formData.documents || [];
    const newDocs = docs.includes(doc)
      ? docs.filter((d) => d !== doc)
      : [...docs, doc];
    setValue("documents", newDocs);
  };

  const onSubmit = async (data) => {
    try {
      console.log("Submitting data:", data);
      const res = await axios.post(
        "http://localhost:4000/scheme/add-scheme",
        data
      );
      console.log(data);
      if (res.data.message === "Login successful") {
        localStorage.setItem("token", res.data.token);
        // navigate("../scheme-form");
      } else {
        console.log(res.data.message);
      }
    } catch (err) {
      console.error("Submission failed", err);
    }
  };

  const docOptions = [
    "Aadhar Card",
    "PAN Card",
    "Voter ID",
    "Ration Card",
    "Bank Passbook",
  ];

  return (
    <section className="container mx-auto px-4 py-12">
      <div className="mx-auto max-w-lg rounded-lg bg-white p-6 shadow-md">
        <h2 className="mb-6 text-center text-2xl font-semibold">
          Government Scheme Details
        </h2>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {[
            { label: "Name of the Scheme", name: "schemeName", type: "text" },
            { label: "Starting Date", name: "startDate", type: "date" },
            { label: "End Date", name: "endDate", type: "date" },
          ].map(({ label, name, type }) => (
            <div key={name}>
              <label htmlFor={name} className="mb-1 block font-medium">
                {label}
              </label>
              <input
                id={name}
                type={type}
                {...register(name, { required: true })}
                className="w-full rounded border border-gray-300 px-3 py-2 focus:border-blue-400 focus:outline-none focus:ring"
              />
              {errors[name] && (
                <p className="text-red-500 text-sm">* Required</p>
              )}
            </div>
          ))}

          <div>
            <label className="mb-1 block font-medium">Occupation</label>
            <Controller
              name="occupation"
              control={control}
              rules={{ required: true }}
              render={({ field }) => (
                <div className="flex gap-6">
                  {["weaver", "rearer", "farmer"].map((val) => (
                    <label
                      key={val}
                      className="flex items-center gap-2 cursor-pointer"
                    >
                      <input
                        type="radio"
                        id={val}
                        value={val}
                        checked={field.value === val}
                        onChange={field.onChange}
                        className="h-4 w-4 text-blue-600"
                      />
                      <span className="capitalize text-sm">{val}</span>
                    </label>
                  ))}
                </div>
              )}
            />
            {errors.occupation && (
              <p className="text-red-500 text-sm">* Required</p>
            )}
          </div>

          <div>
            <label className="mb-1 block font-medium">Required Documents</label>
            <div className="grid grid-cols-2 gap-3">
              {docOptions.map((doc) => (
                <label
                  key={doc}
                  className="flex items-center gap-2 p-2 border rounded cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={formData.documents.includes(doc)}
                    onChange={() => toggleDoc(doc)}
                    className="h-4 w-4 text-blue-600"
                  />
                  <span className="text-sm">{doc}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label htmlFor="benefits" className="mb-1 block font-medium">
              Benefits of the Scheme
            </label>
            <textarea
              id="benefits"
              {...register("benefits", { required: true })}
              rows={3}
              className="w-full resize-y rounded border border-gray-300 px-3 py-2 focus:border-blue-400 focus:outline-none focus:ring"
            />
            {errors.benefits && (
              <p className="text-red-500 text-sm">* Required</p>
            )}
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded"
          >
            Submit
          </button>
        </form>
      </div>
    </section>
  );
}
