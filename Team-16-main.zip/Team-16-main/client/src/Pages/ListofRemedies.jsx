export default function ListofRemedies({ data }) {
  if (!data)
    return (
      <h1 className="text-red-600 text-center text-9xl">Unable to Analyze</h1>
    );

  const { defect_detected, defect_type, remedies } = data;

  return (
    <div className="w-full max-w-xl mx-auto bg-white border rounded-lg shadow p-5 space-y-4">
      <h2 className="text-xl font-semibold text-gray-800">
        🧪 Image Analysis Result
      </h2>

      <div className="text-sm space-y-1">
        <p>
          <strong>Defect Detected:</strong>{" "}
          <span className={defect_detected ? "text-red-600" : "text-green-600"}>
            {defect_detected ? "Yes" : "No"}
          </span>
        </p>
        <p>
          <strong>Defect Type:</strong>{" "}
          <span className="text-gray-700">{defect_type}</span>
        </p>
      </div>

      {remedies?.length > 0 && (
        <div>
          <h3 className="text-md font-medium text-gray-700 mb-2">
            🛠 Immediate Remedies
          </h3>
          <ul className="list-disc list-inside text-sm space-y-1 text-gray-800">
            {remedies.map((step, index) => (
              <li key={index}>{step}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
