import React, { useState } from "react";

export function Tabs({ defaultValue, children }) {
  const [active, setActive] = useState(defaultValue);
  // Filter out only TabsList and TabsContent children
  const tabList = React.Children.toArray(children).find(
    (child) => child.type.displayName === "TabsList"
  );
  const tabContents = React.Children.toArray(children).filter(
    (child) => child.type.displayName === "TabsContent"
  );

  return (
    <div>
      {tabList &&
        React.cloneElement(tabList, { active, setActive })}
      {tabContents.map((child) =>
        React.cloneElement(child, { active })
      )}
    </div>
  );
}

export function TabsList({ children, active, setActive, className }) {
  return (
    <div className={className}>
      {React.Children.map(children, (child) =>
        React.cloneElement(child, { active, setActive })
      )}
    </div>
  );
}
TabsList.displayName = "TabsList";

export function TabsTrigger({ value, children, active, setActive }) {
  return (
    <button
      className={`px-4 py-2 border-b-2 ${
        active === value ? "border-green-700 font-bold" : "border-transparent"
      }`}
      onClick={() => setActive(value)}
      type="button"
    >
      {children}
    </button>
  );
}
TabsTrigger.displayName = "TabsTrigger";

export function TabsContent({ value, children, active, className }) {
  if (active !== value) return null;
  return <div className={className}>{children}</div>;
}
TabsContent.displayName = "TabsContent";
