import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./Pages/Header";
import HomePage from "./Pages/HomePage";
import Register from "./Pages/Register";
import UserLogin from "./Pages/UserLogin";
import AdminLoginPage from "./Pages/AdminLoginPage";
import DashboardPage from "./Pages/DashboardPage";
import GovernmentSchemeForm from "./Pages/GovernmentSchemeForm"; // NEW
import ListofRemedies from "./Pages/ListofRemedies";

export default function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/auth" element={<Register />} />
        <Route path="/login" element={<UserLogin />} />
        <Route path="/admin" element={<AdminLoginPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/scheme-form" element={<GovernmentSchemeForm />} />{" "}
        {/* NEW */}
        <Route path="/analyze" element={<ListofRemedies />} />
        <Route path="*" element={<HomePage />} />
      </Routes>
    </Router>
  );
}
